window.onload = function() {


  fetch("https://api.themoviedb.org/3/movie/popular?api_key=0f61f9e045cc4f90eaffcb0e1aff08fb&language=en-US&page=1")
   .then(function(response) {
     return response.json();
   })
   .then(function(resultado) {


     var nombrePeli1 = resultado.results[0].title;
     var nombrePeli2 = resultado.results[1].title;
     var nombrePeli3 = resultado.results[2].title;
     var nombrePeli4 = resultado.results[3].title;
     var nombrePeli5 = resultado.results[4].title;
     var nombrePeli6 = resultado.results[5].title;

     var url = resultado;
     console.log(url);


     var h1e = document.querySelector(".peli1")
      h1e.innerText=nombrePeli1
    //  var img = document.querySelector(".img1")
    // img.setAttribute("src", url)

    var h1f = document.querySelector(".peli2")
    h1f.innerText=nombrePeli2
//    var img2 = document.querySelector(".img2")
//   img2.setAttribute("src", url)
//
//
  var h1g = document.querySelector(".peli3")
  h1g.innerText=nombrePeli3
//  var img3 = document.querySelector(".img3")
// img3.setAttribute("src", url)
//
var h1h = document.querySelector(".peli4")
h1h.innerText=nombrePeli4
// var img4 = document.querySelector(".img4")
// img4.setAttribute("src", url)
//
var h1i = document.querySelector(".peli5")
h1i.innerText=nombrePeli5
// var img5 = document.querySelector(".img5")
// img5.setAttribute("src", url)
//
var h1j = document.querySelector(".peli6")
h1j.innerText=nombrePeli6
// var img6 = document.querySelector(".img6")
// img6.setAttribute("src", url)


   })
   .catch(function(error) {
     console.log(error);
   })
}
